import React, { useState, useEffect } from "react";
import axios from "axios";
import "./Disbursement.css";

const Disbursement = function DisbursementComponent() {
  const [loanDetails, setLoanDetails] = useState(null);
  const [error, setError] = useState(null);

  const fetchDisbursementDetails = async () => {
    try {
      const response = await axios.post(
        "http://127.0.0.1:8000/disburse-loan/",
        {},
        { headers: { "Content-Type": "application/json" } }
      );
      setLoanDetails(response.data);
      setError(null);
    } catch (err) {
      setError(err.response?.data?.detail || "Failed to fetch loan details.");
      setLoanDetails(null);
    }
  };
useEffect(() => {
  fetchDisbursementDetails();
}, []);
  return (
    <div className="container">
      <div className="disbursement-container">
        <h2 className="disb">Loan Disbursement</h2>
      </div>
      <div>
        {loanDetails && (
          <div className="loan-details">
            <h3>Loan Disbursement Details</h3>
            <p><strong>Applicant Name:</strong> {loanDetails.applicant_name}</p>
            <p><strong>Application Number:</strong> {loanDetails.application_number}</p>
            <p><strong>Loan Amount:</strong> {loanDetails.loan_amount}</p>
            <p><strong>Disbursed Amount:</strong> {loanDetails.disbursed_amount}</p>
            <p><strong>Remaining Amount:</strong> {loanDetails.remaining_amount}</p>
            <p><strong>Status:</strong> {loanDetails.disbursement_status}</p>
          </div>
        )}
        {error && <p className="error-message">❌ {error}</p>}
      </div>
    </div>
  );
};

export default Disbursement;

// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import "./Disbursement.css";

// const Disbursement = function DisbursementComponent() {
//   const [loanDetails, setLoanDetails] = useState(null);
//   const [error, setError] = useState(null);

//   const fetchDisbursementDetails = async () => {
//     try {
//       const response = await axios.post(
//         "http://127.0.0.1:8000/disburse-loan/",
//         {},
//         { headers: { "Content-Type": "application/json" } }
//       );
//       setLoanDetails(response.data);
//       setError(null);
//     } catch (err) {
//       setError(err.response?.data?.detail || "Failed to fetch loan details.");
//       setLoanDetails(null);
//     }
//   };

//   // Automatically start the disbursement process on mount
//   useEffect(() => {
//     fetchDisbursementDetails();
//   }, []);

//   return (
//     <div className="container">
//       <div className="disbursement-container">
//         <h2>Loan Disbursement</h2>
//       </div>
//       <div>
//         {loanDetails && (
//           <div className="loan-details">
//             <h3>Loan Disbursement Details</h3>
//             <p><strong>Applicant Name:</strong> {loanDetails.applicant_name}</p>
//             <p><strong>Application Number:</strong> {loanDetails.application_number}</p>
//             <p><strong>Loan Amount:</strong> {loanDetails.loan_amount}</p>
//             <p><strong>Disbursed Amount:</strong> {loanDetails.disbursed_amount}</p>
//             <p><strong>Remaining Amount:</strong> {loanDetails.remaining_amount}</p>
//             <p><strong>Status:</strong> {loanDetails.disbursement_status}</p>
//           </div>
//         )}
//         {error && <p className="error-message">❌ {error}</p>}
//       </div>
//     </div>
//   );
// };

// export default Disbursement;