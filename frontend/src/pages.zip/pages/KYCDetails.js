// src/components/KYCDetails.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import "./KYCDetails.css";

const KYCDetails = () => {
  const [kycData, setKycData] = useState({});

  useEffect(() => {
    axios
      .get("http://localhost:8000/kyc-details/")
      .then((res) => {
        setKycData(res.data);
      })
      .catch((err) => {
        console.error("Failed to fetch KYC data", err);
      });
  }, []);

  // Helper to format entry rows
  const formatRow = (label, value, confidence) => (
    <tr key={label}>
      <td className="entry-col">{label}</td>
      <td>{value || "-"}</td>
      <td>{typeof confidence === "number" ? confidence.toFixed(2) : "-"}</td>
      </tr>
  );
  const combinedEntries = [];

  Object.entries(kycData).forEach(([_, details]) => {
    if (details.pan_number)
      combinedEntries.push([
        "PAN Number",
        details.pan_number.value,
        details.pan_number.confidence
      ]);
  
    if (details.aadhar_number)
      combinedEntries.push([
        "Aadhar Number",
        details.aadhar_number.value,
        details.aadhar_number.confidence
      ]);
  
    if (details.name)
      combinedEntries.push([
        "Name",
        details.name.value,
        details.name.confidence
      ]);
  
    if (details.dob)
      combinedEntries.push([
        "Date of Birth",
        details.dob.value,
        details.dob.confidence
      ]);
  });
  

return (
    <div className="kyctable-container">
      <h2 className="kyc-heading">KYC Summary Table</h2>
      
      <table className="kyc-table-vertical">
        <thead>
          <tr>
            <th>Entry</th>
            <th>Value</th>
            <th>Confidence Score</th>
          </tr>
        </thead>
        <tbody>
          {combinedEntries.map(([label, value, confidence]) => {
            const confidenceColor =
              typeof confidence === "number" && confidence < 85 ? "low-confidence" : "high-confidence";
        
            return (
              <tr key={label}>
                <td className="entry-col">{label}</td>
                <td>{value || "-"}</td>
                <td className={confidenceColor}>
                  {typeof confidence === "number" ? confidence.toFixed(2) : "-"}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
} 
export default KYCDetails;
