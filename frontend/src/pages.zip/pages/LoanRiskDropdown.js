import React, { useState, useEffect } from 'react';
import './LoanRiskDropdown.css';

function LoanRiskDropdown({ riskStatus }) {
  const [selectedDropdown, setSelectedDropdown] = useState(null);
  const [loanDetails, setLoanDetails] = useState(null);

  const toggleDropdown = (key) => {
    setSelectedDropdown(prev => (prev === key ? null : key));
  };

  // 🔽 Fetch data from /dropdown on component mount
  useEffect(() => {
    const fetchLoanDetails = async () => {
      try {
        const response = await fetch("http://localhost:8000/dropdown");
        const data = await response.json();
        setLoanDetails(data);
      } catch (error) {
        console.error("Error fetching dropdown data:", error);
      }
    };

    fetchLoanDetails();
  }, []);

  const isEligible =
    riskStatus === "❌ Customer is not Eligible for Loan" ||
    riskStatus === "🎉 Customer is Eligible for Loan";

  if (!isEligible || !loanDetails) return null;

  return (
    <div className="risk-dropdown-container">
      {[
        {
          key: 'cibil',
          title: '▸ CIBIL Analysis',
          content: <p>💳 Credit Score: {loanDetails.credit_score}</p>
        },
        {
          key: 'loans',
          title: '▸ Previous Loans',
          content: <p>🔄 Delinquency History: {loanDetails.delinquency_history} missed payments</p>
        },
        {
          key: 'eligibility',
          title: '▸ Eligibility Amount',
          content: <p>📄 Salary Slip Verified: {loanDetails.salary_slip_verified ? "❌ No" : "✅ Yes"}</p>
        },
        {
          key: 'income',
          title: '▸ Income Analysis',
          content: (
            <>
              <p>💳 Credit Score: {loanDetails.credit_score}</p>
              <p>📄 Salary Slip Verified: {loanDetails.salary_slip_verified ? "❌ No" : "✅ Yes"}</p>
              <p>🔄 Delinquency History: {loanDetails.delinquency_history} missed payments</p>
            </>
          )
        }
      ].map(item => (
        <div key={item.key} className="custom-dropdown">
          <button
            className="custom-dropdown-toggle"
            onClick={() => toggleDropdown(item.key)}
          >
            {item.title}
          </button>
          <div className={`custom-dropdown-content ${selectedDropdown === item.key ? 'show' : ''}`}>
            {item.content}
          </div>
        </div>
      ))}
    </div>
  );
}

export default LoanRiskDropdown;
