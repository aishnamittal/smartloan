import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";  // Import Axios for API calls
import "./Login.css";

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // Function to handle login API call
  const handleLogin = async () => {
    if (!email || !password) {
      setLoginError("Please enter both email and password!");
      return;
    }
  
    try {
      const response = await axios.post("http://127.0.0.1:8000/login/", new URLSearchParams({
        username: email,
        password: password,
      }), {
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
      });
  
      console.log("Login response:", response);  // 👈 add this line
  
      // Save token in localStorage
      axios.defaults.headers.common["Authorization"] = `Bearer ${response.data.access_token}`;
      localStorage.setItem("token", response.data.access_token);
  
      navigate("/dashboard");
    } catch (error) {
      console.error("Login error:", error);  // 👈 log the error too
      setLoginError(error.response?.data?.detail || "An error occurred during login");
    }
  };
  
  return (
    <div className="login-container">
      <video autoPlay loop muted className="video-bg">
        <source src="/videos/ey.mp4" type="video/mp4" />
      </video>

      <div className="login-box">
        <img src="https://www.pngall.com/wp-content/uploads/15/EY-Logo-No-Background-180x180.png" alt="Logo" className="logo" />
        <h2>Sign In</h2>
        <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
        {/* Error Message Below Password Field */}
        {loginError && <p className="error-message">{loginError}</p>}
        <button onClick={handleLogin}>Login</button>
      </div>
    </div>
  );
};

export default Login;
