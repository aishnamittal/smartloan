import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { FaPaperclip } from "react-icons/fa"; // Importing paperclip icon
import axios from "axios";
import { FaUser } from "react-icons/fa";
import { v4 as uuidv4 } from "uuid";
import "./Upload.css"; // Ensure you have styles for UI
import OnboardingTab from "./onboarding"; // Import the Onboarding component
import { useNavigate } from "react-router-dom";
import EmailPreview from "./EmailPreview";  // Adjust path if needed
import Disbursement from "./Disbursement.js"; // Import Disbursement component
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import LoanRiskDropdown from './LoanRiskDropdown';

const Upload = () => {
  const [kycVerified, setKycVerified] = useState(null);
  const location = useLocation();
  const initialTab = location.state?.activeTab || "Upload";
  const [activeTab, setActiveTab] = useState(initialTab);
  const [files, setFiles] = useState({});
  const [uuid, setUuid] = useState(null);
  const [creditScore, setCreditScore] = useState(null);
  const [salarySlipVerified, setSalarySlipVerified] = useState(null);
  const [delinquencyHistory, setDelinquencyHistory] = useState(null);
  const [loanEligibilityScore, setLoanEligibilityScore] = useState(null);
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const [panCard, setPanCard] = useState("");
  const [pdfPreview, setPdfPreview] = useState(null);
  const [emailStatus, setEmailStatus] = useState("");
  const navigate = useNavigate();
  const [riskSummary, setRiskSummary] = useState(null);
  const [loanDetails, setLoanDetails] = useState(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const [showCIBIL, setshowCIBIL] = useState(true);
  const [showLoans, setshowLoans] = useState(false);
  const [showEligibility, setshowEligibility] = useState(false);
  const [showSalary, setshowSalary] = useState(false);
  const [uploadStatus, setUploadStatus] = useState({});
  const [kycStepIndex, setKycStepIndex] = useState(-1); // New state to track steps
  const [kycLoading, setKycLoading] = useState(false); // New state for loading status
  const [kycStatus, setKycStatus] = useState(null); // New state for final KYC status
  const [riskStepIndex, setriskStepIndex] = useState(-1);
  const [riskLoading, setriskLoading] = useState(false);
  const [riskStatus, setriskStatus] = useState(null);
  const [risktab, setRiskTab] = useState(true);
  const risktabs = ["Upload", "KYC", "Risk Assessment", "Onboarding", "Disbursement"];
  const backendUrl = "http://127.0.0.1:8000/upload/";
  const backendverifyUrl = "http://127.0.0.1:8000/verify/";
  const kycVerifyUrl = "http://127.0.0.1:8000/KYC"; // Backend endpoint for KYC verification
  const riskVerifyUrl = "http://127.0.0.1:8000/risk-assessment/";
  const sendEmailUrl = "http://127.0.0.1:8000/send-email";
  const kycSteps = [ // Steps displayed in sequence
    "📑 KYC process started",
    "📂 Getting Your Documents ready",
    "🔍 Fetching your details",
    "📝 Scanning your documents",
    "🔄 Cross-checking with the database",
    "📡 Contacting verification servers",
    "🛡️ Ensuring security compliance",
    "✅ Verifying your documents",
    "📊 Finalizing your verification",
  ];
  const riskSteps = [// Steps displayed in sequence
    "📑 Risk assessment process started",
    "📂 Getting Your Documents ready",
    "🔍 Fetching your details",
    "📝 Scanning your documents",
    "🔄 Cross-checking with the database",
    "📡 Contacting verification servers",
    "🛡 Ensuring security compliance",
    "✅ Verifying your documents",
    "📊 Finalizing your verification",
    "🔍 Risk Assessment Summary",
    "⚖ Loan Decision sent through email"
  ];
  const [selectedDropdown, setSelectedDropdown] = useState(null);

const toggleDropdown = (tab) => {
  setSelectedDropdown(selectedDropdown === tab ? null : tab);
};

  const handleFileChange = (e, docType) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFiles((prevFiles) => ({ ...prevFiles, [docType]: selectedFile }));
    }
  };
  // const handVerifyClick = () => {
  // setUuid(uuidv4());
  // setActiveTab("KYC");
  // };
    const handleSendEmail = async () => {
      try {
          const response = await axios.post(sendEmailUrl);
          setEmailStatus(response.data.message || "Email sent successfully!");
      } catch (error) {
          setEmailStatus("❌ Failed to send email. Check server connection.");
          console.error("Error sending email:", error);
      }
  };

  const handleUpload = async (docType) => {
    setActiveTab("Upload");
    if (!files[docType]) {
      return;
    }

    const formData = new FormData();
    formData.append("document_type", docType);
    formData.append("file", files[docType]);

    try {
      await axios.post(backendUrl, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setUploadStatus((prevStatus) => ({
        ...prevStatus,
        [docType]: "success",
      }));

    } catch (error) {
      setUploadStatus((prevStatus) => ({
        ...prevStatus,
        [docType]: "error",
      }));
    }
  };
  
  const handleRiskAssessment = async () => {
    setActiveTab("Risk Assessment Agent");
    setriskStepIndex(0);
    setriskLoading(true);
 
    
    try {
      //  const response = await axios.post(${riskVerifyUrl}, { pan_card: panCardNumber }); // Send PAN card number to backend

      console.log("Risk Assessment Started, But API call pending");

      //  if (response.data && response.data.report) {
      //   setRiskAssessmentReport(response.data.report);
      //   setRiskAssessmentReportLines(response.data.report.split('\n'));
      //  }
    } catch (error) {
      console.error("Risk assessment request failed:", error);
      //  setError("Failed to fetch risk assessment report");
    }
  };
  const handleonboarding= async() => {
    setActiveTab("Onboarding Agent");
  };
  const handledisbursement= async() => {
    setActiveTab("Disbursement");
  };
  const handleLoanRiskDropdown= async() => {
    setActiveTab("LoanRiskDropdown");
  };

  // const handleVerifyClick = async () => {
  //   const uniqueId = Math.floor(10000 + Math.random() * 90000);

  //   setUuid(uniqueId);
  //   setActiveTab("KYC");
  //   setKycStepIndex(0); // Start from the first KYC step
  //   setKycLoading(true); // Begin loading KYC steps

  //   try {
  //     const response = await axios.post(kycVerifyUrl, { uuid: uniqueId });
  //     console.log("Response:", response.data); // Send the new ID to backend
  //   } catch (error) {
  //     console.error("KYC verification request failed:", error);
  //   }
  // };
  const generateNumericUUID = () => {
    return Math.floor(10000 + Math.random() * 90000).toString(); // Generate 5-digit number
};

  const handleVerifyClick = async () => {
      setActiveTab("KYC Agent"); 
      setKycStepIndex(0);
      setKycLoading(true);  

      try {
          // Save UUID and initial stage in MongoDB
          const generatedUuid = generateNumericUUID();
          console.log("Generated UUID:", generatedUuid);
          setUuid(generatedUuid);  
          await axios.post("http://127.0.0.1:8000/api/loan-state", {
              loanApplicationNumber: generatedUuid,
              stage: "Upload"
          });
      } catch (error) {
          console.error("Error saving loan application:", error);
      }
  };
  const updateLoanStage = async (newStage) => {
    if (!uuid) return;
  
    try {
      await axios.put(`http://127.0.0.1:8000/api/loan-state/${uuid}`, null, {
        params: { new_stage: newStage },
      });
      console.log("Stage updated to:", newStage);
      setActiveTab(newStage);
    } catch (error) {
      console.error("Error updating loan stage:", error);
    }
  };
const handleNextStep = () => {
  const stages = ["Upload", "KYC Agent", "Risk Assessment Agent", "Onboarding Agent", "Disbursement"];
  const nextIndex = stages.indexOf(activeTab) + 1;

  if (nextIndex < stages.length) {
    const nextStage = stages[nextIndex];
    updateLoanStage(nextStage);
  }
};



  useEffect(() => { // Handles KYC step transitions
    if (activeTab === "KYC Agent" && kycLoading) {
      fetch(kycVerifyUrl)  // Update with your actual API URL
      .then(response => response.json())
      .then(data => setKycVerified(data.kyc_verified))
      .catch(error => console.error("Error fetching KYC status:", error));
      let stepIndex = 0;
      const interval = setInterval(() => {
        if (stepIndex < kycSteps.length) {
          setKycStepIndex(stepIndex);
          stepIndex++;
        } else {
          clearInterval(interval);
          setKycLoading(false);
          fetchKycVerified(); // Fetch backend verification status after steps finish
        }
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [activeTab, kycLoading]);
  
  useEffect(() => { // Handles Risk Assessment step transitions
    if (activeTab === "Risk Assessment Agent" && riskLoading) {
      let stepIndex = 0;
      const interval = setInterval(() => {
        if (stepIndex < riskSteps.length) {
          setriskStepIndex(stepIndex);
          stepIndex++;
        } else {
          clearInterval(interval);
          setriskLoading(false);
          fetchriskStatus(); // Fetch backend verification status after steps finish
        }
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [activeTab, riskLoading]);

  const fetchKycVerified = async () => { // Fetch KYC verification status from backend
    try {
        const response = await axios.get(kycVerifyUrl);
        console.log(response.data)
        if (response.data[0].kyc_verified === "Yes") { // Updated condition
            setKycVerified("🎉 KYC Successful");  // Updated message
        } else {
            setKycVerified("❌ KYC Failed");  // Updated message
        }
    } catch (error) {
        setKycVerified("❌ Docs Not found");  // Handles API failure case
    }
};
// TO FETCH RISK STATUS  
const fetchriskStatus = async () => { // Fetch Risk Assessment status from backend
  try {
    const response = await axios.get(`${riskVerifyUrl}`);
    console.log(response.data)
    if (response.data.loan_status?.loan_eligibility === "Approved") {
      setriskStatus("🎉 Customer is Eligible for Loan");
      setLoanDetails(response.data);
    } else {
      setriskStatus("❌ Customer is not Eligible for Loan");
    }
  } catch (error) {
    setriskStatus("❌ Risk assessment Failed");
 }
 };
// const fetchriskStatus = async () => { // Fetch Risk Assessment status from backend
//   try {
//     const response = await axios.get(`${riskVerifyUrl}`);
//     if (response.data.loan_eligibility === "Approved") {
//       setriskStatus("🎉 Loan amount approved");
//     } else {
//       setriskStatus("❌ Loan amount rejected");
//     }
//     // Fetch additional customer data from response
//     setCreditScore(response.data.credit_score);
//     setSalarySlipVerified(response.data.salary_slip_verified ? "Verified ✅" : "Not Verified ❌");
//     setDelinquencyHistory(response.data.delinquency_history);
//     setLoanEligibilityScore(response.data.loan_eligibility_score);
        
//     // Show dropdown menu
//     setDropdownVisible(true);Han
//   } catch (error) {
//     setriskStatus("❌ Risk assessment Failed" );
//   }
// };
  const documents = [
    { name: "PAN" },
    { name: "Aadhar" },
    { name: "Loan-Application" },
    { name: "Salary-slip" },
  ];
  const tabs = ["Upload", "KYC Agent", "Risk Assessment Agent", "Onboarding Agent", "Disbursement"];


  // return (
  //   <div className="upload-container">
  //     {/* Tab Navigation */}
  //     <div className="tab-bar">
  //       {["Upload", "KYC", "Risk Assessment", "Onboarding", "Disbursement"].map((tab) => (
  //         <button key={tab} className={`tab-button ${activeTab === tab ? "active" : ""}`} onClick={() => setActiveTab(tab)}>
  //           {tab}
  //         </button>
  //       ))}
  //     </div>
  return (
    <div className="upload-container">
      {/* Tab Navigation */}
      <div className="tab-bar">
        {tabs.map((tab) => (
          <button
            key={tab}
            className={`tab-button ${activeTab === tab ? "active" : ""}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>
      <div className="uuid">
      <p className="uuidtext"><FaUser className="login-icon" />{uuid}</p>
      </div>

      {/* Tab Content */}
      <div className="tab-content">
        {activeTab === "Upload" && (
          <div className="upload-box">
            <h2>Upload Documents</h2>
            <table className="styled-table">
              <thead>
                <tr>
                  <th>Documentation</th>
                  <th>Status</th>
                  <th>Attach</th>
                  <th>Submit</th>
                </tr>
              </thead>
              <tbody>
                {documents.map((doc, index) => (
                  <tr key={index}>
                    <td>{doc.name}</td>
                    <td>
                      <span
                        className={
                          uploadStatus[doc.name] === "success"
                            ? "submitted-badge"
                            : "required-badge"
                        }
                      >
                        {uploadStatus[doc.name] === "success"
                          ? "Submitted"
                          : "Required"}
                      </span>
                    </td>
                    <td>
                      <label className="attach-icon">
                        <input
                          type="file"
                          style={{ display: "none" }}
                          onChange={(e) => handleFileChange(e, doc.name)}
                          id={`file-input-${index}`}
                        />
                        <button
                          className="paperclip-btn"
                          onClick={(e) => {
                            e.preventDefault();
                            document.getElementById(`file-input-${index}`).click();
                          }}
                        >
                          <FaPaperclip size={11} />
                        </button>
                      </label>
                    </td>
                    <td>
                      <button className="small-submit-btn" onClick={() => handleUpload(doc.name)}>
                        Submit
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Verify Button - Positioned at the bottom left */}
            <button className="verify-button" onClick={() =>{handleVerifyClick();handleNextStep();}}>
              Verify
            </button>          
            </div>
        )}

        {/* KYC PROCESS DISPLAY */}
        {activeTab === "KYC Agent" && (
        <div className="kyc-container">
        <div className="kyc-gif-box">
        <img
        src={
          kycLoading
            ? "https://media.licdn.com/dms/image/sync/v2/D5627AQEJQN0F1uPrgw/articleshare-shrink_800/articleshare-shrink_800/0/1733051406666?e=2147483647&v=beta&t=McWWzzDupD-oTXWodo0WwogprMx1BxYFk7cngqBUvLk" // Thinking GIF
            : kycVerified === "❌ KYC Failed" || kycVerified === "❌ Docs Not found"
            ? "https://portal.maktabsoft.ir/95136081/component/messenger/assets/images/failed.gif" // Oops GIF
            : "https://cdn.dribbble.com/userupload/15097592/file/original-11af0dab65a0913fe4ea1d71d9d48f4a.gif" // successful GIF
        }
        alt="KYC Process"
        className="kyc-gif"
      />
      <p className="kyc-gif-text">
        {kycLoading
          ? "Agent Is Processing"
          : kycVerified === "❌ KYC Failed" || kycVerified === "❌ Docs Not found"
          ? "Oops! Something went wrong"
          : "🎉 KYC Successful"}
        <span className="dots"></span>
      </p>
      </div>
          <div className="kyc-content">  
            <h2>KYC Section</h2>
            <div className="kyc-status">
              {kycLoading ? (
                <p>
                  {kycSteps.slice(0, kycStepIndex + 1).map((step, index) => (
                    <span key={index}>
                      {step}
                      <br />
                    </span>
                  ))}
                </p>
              ) : (
                <p>{kycVerified}</p> // Display final status after steps
              )}
            </div>
            {(kycVerified === "🎉 KYC Successful") &&(
            <button class="next-button" onClick={() =>{handleRiskAssessment();handleNextStep();}}>Next step</button>
          )}
            {(kycVerified === "❌ KYC Failed" || kycVerified === "❌ Docs Not found") &&(
            <button class="next-button" onClick={() =>{handleUpload();handleNextStep();}}>Retry</button>
          )}
          </div> 
          </div>
        )}

        {/* Risk PROCESS DISPLAY */}
        {activeTab === "Risk Assessment Agent" && (
  <div className="risk-page-wrapper">
    {/* Left: Risk Container */}
    <div className="risk-container">
      <div className="kyc-gif-box">
        <img
          src={
            riskLoading
              ? "https://media.licdn.com/dms/image/sync/v2/D5627AQEJQN0F1uPrgw/articleshare-shrink_800/articleshare-shrink_800/0/1733051406666?e=2147483647&v=beta&t=McWWzzDupD-oTXWodo0WwogprMx1BxYFk7cngqBUvLk"
              : riskStatus === "❌ Risk assessment Failed" ||
                riskStatus === "❌ Agent Faced an issue"
              ? "https://portal.maktabsoft.ir/95136081/component/messenger/assets/images/failed.gif"
              : "https://cdn.dribbble.com/userupload/15097592/file/original-11af0dab65a0913fe4ea1d71d9d48f4a.gif"
          }
          alt="KYC Process"
          className="kyc-gif"
        />
        <p className="kyc-gif-text">
          {riskLoading
            ? "Agent Is Processing"
            : riskStatus === "❌ Risk assessment Failed" ||
              riskStatus === "❌ Agent Faced an issue"
            ? "Oops! Something went wrong"
            : "🎉 Risk Assessment Successful"}
          <span className="dots"></span>
        </p>
      </div>

      {/* {(riskStatus === "❌ Customer is not Eligible for Loan" ||
        riskStatus === "🎉 Customer is Eligible for Loan") && (
        <>
          {showCIBIL && loanDetails && (
            <div className="risk-dropdown"
                    onClick={() => setshowCIBIL(!showCIBIL)}>
              <p>💳 Credit Score</p>
            </div>
          )}
          {showLoans && loanDetails && (
            <div className="risk-dropdown"onClick={() => setshowLoans(!showLoans)}>
              <p>
                🔄 Delinquency History: {loanDetails.delinquency_history} missed
                payments
              </p>
            </div>
          )}
          {showEligibility && loanDetails && (
            <div className="risk-dropdown">
              <p>
                📄 Salary Slip Verified:{" "}
                {loanDetails.salary_slip_verified ? "✅ Yes" : "❌ No"}
              </p>
            </div>
          )}
          {showSalary && loanDetails && (
            <div className="risk-dropdown">
              <p>💳 Credit Score: {loanDetails.credit_score}</p>
              <p>
                📄 Salary Slip Verified:{" "}
                {loanDetails.salary_slip_verified ? "✅ Yes" : "❌ No"}
              </p>
              <p>
                🔄 Delinquency History: {loanDetails.delinquency_history} missed
                payments
              </p>
            </div>
          )}
        </>
      )} */}

      <div className="risk-section">
        <h2 className="risk-box">Risk Assessment Section</h2>
        <div className="risk-status">
          {riskLoading ? (
            <p>
              {riskSteps.slice(0, riskStepIndex + 1).map((step, index) => (
                <span key={index}>
                  {step}
                  <br />
                </span>
              ))}
            </p>
          ) : (
            <p>{riskStatus}</p>
          )}
        </div>

        {(riskStatus === "❌ Customer is not Eligible for Loan" || riskStatus === "🎉 Customer is Eligible for Loan") && <EmailPreview />}

        {riskStatus === "🎉 Customer is Eligible for Loan" && (
          <>
            <button
              className="approve-button"
              onClick={() => {
                handleonboarding();
                handleNextStep();
              }}
            >
              Approve
            </button>
            <button
              className="reject-button"
              onClick={() => {
                handleonboarding();
                handleNextStep();
              }}
            >
              Reject
            </button>
          </>
        )}

        {riskStatus === "❌ Customer is not Eligible for Loan" && (
          <>
            <button
              className="approve-button"
              onClick={() => {
                handleonboarding();
                handleNextStep();
              }}
            >
              Approve
            </button>
            <button
              className="reject-button"
              onClick={() => {
                handleonboarding();
                handleNextStep();
              }}
            >
              Reject
            </button>
          </>
        )}

        {(riskStatus === "❌ Customer is not Eligible for Loan" ||
          riskStatus === "🎉 Customer is Eligible for Loan") && (
          <button
            className="risk-report-button"
            onClick={() => setRiskTab(!risktab)}
          >
            Loan Risk Report
          </button>
        )}
      </div>
    </div>

    {/* Right: Dropdown Sidebar */}
    {loanDetails && (
  <LoanRiskDropdown
    riskStatus={riskStatus}
    loanDetails={loanDetails}
  />
)}
  </div>
)}

        {activeTab === "Review" && (
          <div className="review-container">
            <h2>Final Review</h2>
            <p>All steps completed. Ready for onboarding.</p>
            <button className="next-button" onClick={() =>{handleonboarding();handleNextStep();}}>Next</button>
          </div>
        )}
        {activeTab === "Onboarding Agent" && <OnboardingTab />}
      </div>
        {activeTab === "Onboarding Agent" &&(
          <div>
              <button className="proceed-button" onClick={() =>{handledisbursement();handleNextStep();}}>
                Proceed
              </button> 
          </div>
      )}
      {activeTab === "Disbursement" && <Disbursement />}
              {/* ✅ Added Onboarding Component */}
{/* <div className="tab-bar">
  {["Upload", "KYC", "Risk Assessment", "Review", "Onboarding", "Disbursement"].map((tab) => (
    <button key={tab} className={tab-button ${activeTab === tab ? "active" : ""}} onClick={() => setActiveTab(tab)}>
      {tab}
    </button>
  ))}
</div> */}
    </div>
  );
};


export default Upload;
